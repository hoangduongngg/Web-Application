package product_maintenance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductMaintenanceApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(ProductMaintenanceApplication.class, args);
	}

}
